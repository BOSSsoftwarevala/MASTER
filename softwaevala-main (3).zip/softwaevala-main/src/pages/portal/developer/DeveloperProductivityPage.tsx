import { RoleLayout } from '@/components/layout/RoleLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { TrendingUp, Clock, CheckCircle, Activity, Zap, Target } from 'lucide-react';

const productivityMetrics = {
  score: 87,
  tasksCompleted: 12,
  avgCompletionTime: '3.2h',
  codeQuality: 94,
  reviewSpeed: 'Fast',
  activeHours: 34,
  idleHours: 2,
};

const weeklyBreakdown = [
  { day: 'Mon', active: 7.5, idle: 0.5 },
  { day: 'Tue', active: 8, idle: 0 },
  { day: 'Wed', active: 6.5, idle: 1 },
  { day: 'Thu', active: 7, idle: 0.5 },
  { day: 'Fri', active: 5, idle: 0 },
];

export default function DeveloperProductivityPage() {
  return (
    <RoleLayout role="developer">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Productivity Score</h1>
            <p className="text-muted-foreground">Your performance metrics this week</p>
          </div>
          <Badge variant="outline" className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
            <TrendingUp className="h-3 w-3 mr-1" />
            +5% vs Last Week
          </Badge>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card className="md:col-span-1">
            <CardContent className="p-6 text-center">
              <div className="relative w-32 h-32 mx-auto mb-4">
                <svg className="w-full h-full" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" className="text-muted/20" strokeWidth="10" />
                  <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" className="text-cyan-400" strokeWidth="10"
                    strokeDasharray={`${productivityMetrics.score * 2.83} 283`} strokeLinecap="round" transform="rotate(-90 50 50)" />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-4xl font-bold">{productivityMetrics.score}</span>
                </div>
              </div>
              <p className="text-lg font-medium">Productivity Score</p>
              <p className="text-sm text-muted-foreground">Excellent performance</p>
            </CardContent>
          </Card>

          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Weekly Activity
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {weeklyBreakdown.map((day) => (
                <div key={day.day} className="flex items-center gap-4">
                  <span className="w-10 text-sm font-medium">{day.day}</span>
                  <div className="flex-1 flex items-center gap-2">
                    <div className="flex-1 h-4 bg-muted rounded-full overflow-hidden flex">
                      <div className="h-full bg-cyan-500" style={{ width: `${(day.active / 8) * 100}%` }} />
                      <div className="h-full bg-amber-500/50" style={{ width: `${(day.idle / 8) * 100}%` }} />
                    </div>
                  </div>
                  <span className="text-sm text-muted-foreground w-16">{day.active}h active</span>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle className="h-4 w-4 text-emerald-400" />
                <span className="text-sm text-muted-foreground">Tasks Done</span>
              </div>
              <p className="text-2xl font-bold">{productivityMetrics.tasksCompleted}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Clock className="h-4 w-4 text-blue-400" />
                <span className="text-sm text-muted-foreground">Avg Time</span>
              </div>
              <p className="text-2xl font-bold">{productivityMetrics.avgCompletionTime}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Zap className="h-4 w-4 text-amber-400" />
                <span className="text-sm text-muted-foreground">Code Quality</span>
              </div>
              <p className="text-2xl font-bold">{productivityMetrics.codeQuality}%</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Target className="h-4 w-4 text-violet-400" />
                <span className="text-sm text-muted-foreground">Review Speed</span>
              </div>
              <p className="text-2xl font-bold">{productivityMetrics.reviewSpeed}</p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-4">
              <div className="flex-1">
                <p className="text-sm text-muted-foreground mb-1">Active Hours: {productivityMetrics.activeHours}h</p>
                <Progress value={(productivityMetrics.activeHours / 40) * 100} className="h-2" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-muted-foreground mb-1">Idle Time: {productivityMetrics.idleHours}h</p>
                <Progress value={(productivityMetrics.idleHours / 40) * 100} className="h-2 [&>div]:bg-amber-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </RoleLayout>
  );
}
