import { RoleLayout } from '@/components/layout/RoleLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { 
  Clock, 
  Play,
  Pause,
  Calendar,
  CheckCircle,
  TrendingUp,
  Plus
} from 'lucide-react';
import { useState } from 'react';

const timeLogs = [
  { 
    id: 1,
    task: 'Implement user authentication flow',
    project: 'Main Platform',
    hours: 4.5,
    date: 'Today',
    status: 'approved',
    billable: true
  },
  { 
    id: 2,
    task: 'Fix payment gateway integration',
    project: 'E-commerce Module',
    hours: 2.0,
    date: 'Today',
    status: 'pending',
    billable: true
  },
  { 
    id: 3,
    task: 'Code review for PR #234',
    project: 'Main Platform',
    hours: 1.5,
    date: 'Yesterday',
    status: 'approved',
    billable: true
  },
  { 
    id: 4,
    task: 'Team standup meeting',
    project: 'General',
    hours: 0.5,
    date: 'Yesterday',
    status: 'approved',
    billable: false
  },
  { 
    id: 5,
    task: 'Database optimization research',
    project: 'API Server',
    hours: 3.0,
    date: '2 days ago',
    status: 'approved',
    billable: true
  },
];

const weeklyStats = {
  hoursLogged: 36,
  targetHours: 40,
  billableHours: 32,
  nonBillableHours: 4,
};

export default function DeveloperTimeLogPage() {
  const [isTracking, setIsTracking] = useState(false);
  const [currentTime, setCurrentTime] = useState('00:00:00');

  return (
    <RoleLayout role="developer">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Time Tracking</h1>
            <p className="text-muted-foreground">Log and track your working hours</p>
          </div>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Manual Entry
          </Button>
        </div>

        {/* Timer */}
        <Card className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
          <CardContent className="py-8">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Current Session</p>
                <p className="text-5xl font-mono font-bold">{currentTime}</p>
                <p className="text-sm text-muted-foreground mt-2">
                  Task: {isTracking ? 'Fix payment gateway integration' : 'No active task'}
                </p>
              </div>
              <Button 
                size="lg" 
                onClick={() => setIsTracking(!isTracking)}
                className={isTracking ? 'bg-red-600 hover:bg-red-700' : 'bg-emerald-600 hover:bg-emerald-700'}
              >
                {isTracking ? (
                  <>
                    <Pause className="h-5 w-5 mr-2" />
                    Stop
                  </>
                ) : (
                  <>
                    <Play className="h-5 w-5 mr-2" />
                    Start
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Weekly Stats */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-cyan-500/20 flex items-center justify-center">
                  <Clock className="h-5 w-5 text-cyan-500" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">This Week</p>
                  <p className="text-2xl font-bold">{weeklyStats.hoursLogged}h</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-emerald-500/20 flex items-center justify-center">
                  <CheckCircle className="h-5 w-5 text-emerald-500" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Billable</p>
                  <p className="text-2xl font-bold">{weeklyStats.billableHours}h</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-slate-500/20 flex items-center justify-center">
                  <Calendar className="h-5 w-5 text-slate-500" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Non-Billable</p>
                  <p className="text-2xl font-bold">{weeklyStats.nonBillableHours}h</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                  <TrendingUp className="h-5 w-5 text-blue-500" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Target Progress</p>
                  <p className="text-2xl font-bold">{Math.round((weeklyStats.hoursLogged / weeklyStats.targetHours) * 100)}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Progress Bar */}
        <Card>
          <CardContent className="py-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm">Weekly Target Progress</span>
              <span className="text-sm font-medium">{weeklyStats.hoursLogged} / {weeklyStats.targetHours} hours</span>
            </div>
            <Progress value={(weeklyStats.hoursLogged / weeklyStats.targetHours) * 100} className="h-3" />
          </CardContent>
        </Card>

        {/* Time Logs */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Time Entries</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {timeLogs.map((log) => (
                <div key={log.id} className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-4">
                    <div className="h-10 w-10 rounded-lg bg-cyan-500/20 flex items-center justify-center">
                      <Clock className="h-5 w-5 text-cyan-500" />
                    </div>
                    <div>
                      <p className="font-medium">{log.task}</p>
                      <p className="text-sm text-muted-foreground">{log.project}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="font-medium">{log.hours}h</p>
                      <p className="text-xs text-muted-foreground">{log.date}</p>
                    </div>
                    <div className="flex flex-col gap-1">
                      <Badge variant="outline" className={
                        log.status === 'approved' 
                          ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                          : 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                      }>
                        {log.status}
                      </Badge>
                      <Badge variant="outline" className={
                        log.billable 
                          ? 'bg-blue-500/20 text-blue-400 border-blue-500/30'
                          : 'bg-slate-500/20 text-slate-400 border-slate-500/30'
                      }>
                        {log.billable ? 'Billable' : 'Non-billable'}
                      </Badge>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </RoleLayout>
  );
}
