import { RoleLayout } from '@/components/layout/RoleLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Workflow, CheckCircle, XCircle, Clock, Play, AlertTriangle } from 'lucide-react';

const pipelines = [
  { id: 1, name: 'main-platform', branch: 'main', status: 'success', stages: ['Build', 'Test', 'Deploy'], duration: '4m 23s', time: '10 min ago' },
  { id: 2, name: 'main-platform', branch: 'feature/auth', status: 'running', stages: ['Build', 'Test'], duration: '2m 15s', time: 'Now' },
  { id: 3, name: 'api-server', branch: 'develop', status: 'failed', stages: ['Build', 'Test'], duration: '1m 45s', time: '25 min ago', error: 'Test failed: auth.spec.ts' },
  { id: 4, name: 'mobile-app', branch: 'main', status: 'success', stages: ['Build', 'Test', 'Deploy'], duration: '6m 12s', time: '1h ago' },
];

export default function DeveloperPipelinePage() {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success': return <CheckCircle className="h-5 w-5 text-emerald-400" />;
      case 'failed': return <XCircle className="h-5 w-5 text-red-400" />;
      case 'running': return <Play className="h-5 w-5 text-blue-400 animate-pulse" />;
      default: return <Clock className="h-5 w-5 text-muted-foreground" />;
    }
  };

  return (
    <RoleLayout role="developer">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">CI/CD Pipeline</h1>
            <p className="text-muted-foreground">Build and deployment status (read-only)</p>
          </div>
          <Badge variant="outline" className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
            <Workflow className="h-3 w-3 mr-1" />
            {pipelines.filter(p => p.status === 'running').length} Running
          </Badge>
        </div>

        <div className="space-y-4">
          {pipelines.map((pipeline) => (
            <Card key={pipeline.id}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    {getStatusIcon(pipeline.status)}
                    <div>
                      <h3 className="font-medium">{pipeline.name}</h3>
                      <p className="text-sm text-muted-foreground">{pipeline.branch}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-6">
                    <div className="flex items-center gap-2">
                      {pipeline.stages.map((stage, idx) => (
                        <Badge key={idx} variant="outline" className={
                          pipeline.status === 'success' ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' :
                          pipeline.status === 'failed' && idx === pipeline.stages.length - 1 ? 'bg-red-500/20 text-red-400 border-red-500/30' :
                          pipeline.status === 'running' && idx === pipeline.stages.length - 1 ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' :
                          'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                        }>
                          {stage}
                        </Badge>
                      ))}
                    </div>
                    <span className="text-sm text-muted-foreground w-20">{pipeline.duration}</span>
                    <span className="text-sm text-muted-foreground w-24 text-right">{pipeline.time}</span>
                  </div>
                </div>
                {pipeline.error && (
                  <div className="mt-3 p-2 rounded bg-red-500/10 border border-red-500/30 flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-red-400" />
                    <span className="text-sm text-red-400">{pipeline.error}</span>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="bg-amber-500/10 border-amber-500/30">
          <CardContent className="p-4 flex items-center gap-3">
            <AlertTriangle className="h-5 w-5 text-amber-400" />
            <p className="text-sm text-amber-400">
              This is a read-only view. Triggering or canceling pipelines requires Manager approval.
            </p>
          </CardContent>
        </Card>
      </div>
    </RoleLayout>
  );
}
