import { RoleLayout } from '@/components/layout/RoleLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Rocket, 
  Clock,
  CheckCircle,
  AlertTriangle,
  FileText,
  GitBranch,
  Tag
} from 'lucide-react';

const releases = [
  { 
    id: 1,
    version: 'v2.1.0',
    title: 'January Feature Release',
    type: 'major',
    status: 'pending_review',
    features: ['New analytics dashboard', 'Export functionality', 'Dark mode support'],
    fixes: ['Login timeout issue', 'Payment calculation bug'],
    breakingChanges: [],
    scheduledFor: 'Jan 10, 2026',
    author: 'You'
  },
  { 
    id: 2,
    version: 'v2.0.5',
    title: 'Hotfix: Auth Session',
    type: 'patch',
    status: 'deployed',
    features: [],
    fixes: ['Fixed session timeout causing random logouts'],
    breakingChanges: [],
    releasedAt: 'Jan 3, 2026',
    author: 'Sarah K.'
  },
  { 
    id: 3,
    version: 'v2.0.4',
    title: 'Payment Gateway Update',
    type: 'minor',
    status: 'deployed',
    features: ['Support for international cards'],
    fixes: ['Currency conversion display'],
    breakingChanges: [],
    releasedAt: 'Dec 28, 2025',
    author: 'Mike J.'
  },
];

const upcomingReleases = [
  { version: 'v2.2.0', title: 'Q1 Major Release', scheduledFor: 'Feb 15, 2026', status: 'planning' },
  { version: 'v2.1.1', title: 'Bug Fixes', scheduledFor: 'Jan 20, 2026', status: 'in_development' },
];

export default function DeveloperReleasesPage() {
  return (
    <RoleLayout role="developer">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Release Notes Viewer</h1>
            <p className="text-muted-foreground">View release history and upcoming deployments</p>
          </div>
          <Badge variant="outline" className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
            <Tag className="h-3 w-3 mr-1" />
            Current: v2.0.5
          </Badge>
        </div>

        {/* Upcoming Releases */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Upcoming Releases
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2">
              {upcomingReleases.map((release, idx) => (
                <div key={idx} className="p-4 rounded-lg border bg-muted/50">
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="outline" className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
                      {release.version}
                    </Badge>
                    <Badge variant="outline" className={
                      release.status === 'planning' 
                        ? 'bg-slate-500/20 text-slate-400 border-slate-500/30'
                        : 'bg-blue-500/20 text-blue-400 border-blue-500/30'
                    }>
                      {release.status.replace('_', ' ')}
                    </Badge>
                  </div>
                  <p className="font-medium">{release.title}</p>
                  <p className="text-sm text-muted-foreground flex items-center gap-1 mt-2">
                    <Clock className="h-3 w-3" />
                    Scheduled: {release.scheduledFor}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Release History */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Rocket className="h-5 w-5" />
              Release History
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {releases.map((release) => (
                <div key={release.id} className={`p-4 rounded-lg border ${
                  release.status === 'pending_review' ? 'border-amber-500/30 bg-amber-500/10' :
                  'border-muted'
                }`}>
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className={`h-10 w-10 rounded-lg flex items-center justify-center ${
                        release.type === 'major' ? 'bg-violet-500/20' :
                        release.type === 'minor' ? 'bg-blue-500/20' :
                        'bg-slate-500/20'
                      }`}>
                        <Tag className={`h-5 w-5 ${
                          release.type === 'major' ? 'text-violet-500' :
                          release.type === 'minor' ? 'text-blue-500' :
                          'text-slate-500'
                        }`} />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-lg">{release.version}</span>
                          <Badge variant="outline" className={
                            release.type === 'major' ? 'bg-violet-500/20 text-violet-400 border-violet-500/30' :
                            release.type === 'minor' ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' :
                            'bg-slate-500/20 text-slate-400 border-slate-500/30'
                          }>
                            {release.type}
                          </Badge>
                        </div>
                        <p className="font-medium">{release.title}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge variant="outline" className={
                        release.status === 'deployed' ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' :
                        'bg-amber-500/20 text-amber-400 border-amber-500/30'
                      }>
                        {release.status === 'deployed' ? (
                          <><CheckCircle className="h-3 w-3 mr-1" /> Deployed</>
                        ) : (
                          <><Clock className="h-3 w-3 mr-1" /> Pending Review</>
                        )}
                      </Badge>
                      <p className="text-xs text-muted-foreground mt-1">
                        {release.releasedAt || `Scheduled: ${release.scheduledFor}`}
                      </p>
                      <p className="text-xs text-muted-foreground">by {release.author}</p>
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    {release.features.length > 0 && (
                      <div>
                        <p className="text-sm font-medium text-emerald-400 mb-2">✨ Features</p>
                        <ul className="space-y-1">
                          {release.features.map((feature, i) => (
                            <li key={i} className="text-sm text-muted-foreground">• {feature}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                    {release.fixes.length > 0 && (
                      <div>
                        <p className="text-sm font-medium text-blue-400 mb-2">🐛 Bug Fixes</p>
                        <ul className="space-y-1">
                          {release.fixes.map((fix, i) => (
                            <li key={i} className="text-sm text-muted-foreground">• {fix}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>

                  {release.breakingChanges.length > 0 && (
                    <div className="mt-4 p-3 rounded bg-red-500/10 border border-red-500/30">
                      <p className="text-sm font-medium text-red-400 mb-2">⚠️ Breaking Changes</p>
                      <ul className="space-y-1">
                        {release.breakingChanges.map((change, i) => (
                          <li key={i} className="text-sm text-muted-foreground">• {change}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="flex gap-3">
          <Button variant="outline">
            <FileText className="h-4 w-4 mr-2" />
            Export Changelog
          </Button>
          <Button variant="outline">
            <GitBranch className="h-4 w-4 mr-2" />
            View Git History
          </Button>
        </div>
      </div>
    </RoleLayout>
  );
}
