import { RoleLayout } from '@/components/layout/RoleLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Megaphone, Pin, Calendar, AlertTriangle, Info } from 'lucide-react';

const announcements = [
  { id: 1, title: 'System Maintenance Scheduled', content: 'Scheduled maintenance on Jan 10, 2025 from 2 AM to 6 AM PST. All services will be temporarily unavailable.', type: 'warning', pinned: true, date: 'Jan 6, 2025' },
  { id: 2, title: 'New Code Review Guidelines', content: 'Updated code review process: All PRs now require 2 approvals before merge. Please review the updated documentation.', type: 'info', pinned: true, date: 'Jan 5, 2025' },
  { id: 3, title: 'Sprint 24 Kickoff', content: 'Sprint 24 starts tomorrow. Please check your assigned tasks and update estimates in the sprint board.', type: 'info', pinned: false, date: 'Jan 4, 2025' },
  { id: 4, title: 'Holiday Schedule', content: 'Office will be closed on Jan 20 for MLK Day. Adjust your deadlines accordingly.', type: 'info', pinned: false, date: 'Jan 3, 2025' },
];

export default function DeveloperAnnouncementsPage() {
  return (
    <RoleLayout role="developer">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Announcement Board</h1>
            <p className="text-muted-foreground">Team updates and notices</p>
          </div>
          <Badge variant="outline" className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
            <Megaphone className="h-3 w-3 mr-1" />
            {announcements.length} Announcements
          </Badge>
        </div>

        <div className="space-y-4">
          {announcements.map((announcement) => (
            <Card key={announcement.id} className={announcement.pinned ? 'border-cyan-500/30' : ''}>
              <CardContent className="p-4">
                <div className="flex items-start gap-4">
                  <div className={`p-2 rounded-lg ${announcement.type === 'warning' ? 'bg-amber-500/20' : 'bg-blue-500/20'}`}>
                    {announcement.type === 'warning' 
                      ? <AlertTriangle className="h-5 w-5 text-amber-400" />
                      : <Info className="h-5 w-5 text-blue-400" />
                    }
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="font-medium">{announcement.title}</h3>
                      {announcement.pinned && (
                        <Pin className="h-4 w-4 text-cyan-400" />
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">{announcement.content}</p>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Calendar className="h-3 w-3" />
                      <span>{announcement.date}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </RoleLayout>
  );
}
