import { RoleLayout } from '@/components/layout/RoleLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { ListTodo, Search, Clock, AlertTriangle, CheckCircle } from 'lucide-react';
import { useState } from 'react';

// Mock data
const tasks = [
  { id: 1, title: 'Implement user authentication flow', project: 'Main Platform', priority: 'high', status: 'in_progress', deadline: 'Jan 6', progress: 75, estimate: '8h', logged: '6h' },
  { id: 2, title: 'Fix payment gateway integration', project: 'E-commerce Module', priority: 'critical', status: 'in_progress', deadline: 'Jan 5', progress: 40, estimate: '4h', logged: '1.5h' },
  { id: 3, title: 'Add export functionality', project: 'Reports Dashboard', priority: 'medium', status: 'todo', deadline: 'Jan 8', progress: 0, estimate: '6h', logged: '0h' },
  { id: 4, title: 'Optimize database queries', project: 'API Server', priority: 'medium', status: 'todo', deadline: 'Jan 10', progress: 0, estimate: '5h', logged: '0h' },
  { id: 5, title: 'Write unit tests for auth module', project: 'Main Platform', priority: 'low', status: 'review', deadline: 'Jan 7', progress: 100, estimate: '3h', logged: '3.5h' },
];

export default function DeveloperTasksPage() {
  const [search, setSearch] = useState('');

  const filteredTasks = tasks.filter(task => 
    task.title.toLowerCase().includes(search.toLowerCase()) ||
    task.project.toLowerCase().includes(search.toLowerCase())
  );

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'in_progress': return <Clock className="h-4 w-4 text-blue-500" />;
      case 'review': return <AlertTriangle className="h-4 w-4 text-amber-500" />;
      case 'completed': return <CheckCircle className="h-4 w-4 text-emerald-500" />;
      default: return <ListTodo className="h-4 w-4 text-muted-foreground" />;
    }
  };

  return (
    <RoleLayout role="developer">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Active Tasks</h1>
            <p className="text-muted-foreground">Your assigned development tasks</p>
          </div>
          <Badge variant="outline" className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
            <ListTodo className="h-3 w-3 mr-1" />
            {tasks.filter(t => t.status !== 'completed').length} Active
          </Badge>
        </div>

        <div className="flex items-center gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Search tasks..." 
              className="pl-9" 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <Button variant="outline">Filter</Button>
        </div>

        <div className="space-y-4">
          {filteredTasks.map((task) => (
            <Card key={task.id}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-start gap-3">
                    {getStatusIcon(task.status)}
                    <div>
                      <h3 className="font-medium">{task.title}</h3>
                      <p className="text-sm text-muted-foreground">{task.project}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className={
                      task.priority === 'critical' ? 'bg-red-500/20 text-red-400 border-red-500/30' :
                      task.priority === 'high' ? 'bg-amber-500/20 text-amber-400 border-amber-500/30' :
                      task.priority === 'medium' ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' :
                      'bg-slate-500/20 text-slate-400 border-slate-500/30'
                    }>
                      {task.priority}
                    </Badge>
                    <Badge variant="outline">
                      {task.status.replace('_', ' ')}
                    </Badge>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs text-muted-foreground">Progress</span>
                      <span className="text-xs font-medium">{task.progress}%</span>
                    </div>
                    <Progress value={task.progress} className="h-1" />
                  </div>
                  <div className="text-right text-sm">
                    <p className="text-muted-foreground">Due: {task.deadline}</p>
                    <p className="text-muted-foreground">{task.logged} / {task.estimate}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </RoleLayout>
  );
}
