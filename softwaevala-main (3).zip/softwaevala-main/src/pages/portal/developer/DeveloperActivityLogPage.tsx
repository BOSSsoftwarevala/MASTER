import { RoleLayout } from '@/components/layout/RoleLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Activity, Search, GitCommit, FileCode, Eye, LogIn, LogOut } from 'lucide-react';
import { useState } from 'react';

const activityLogs = [
  { id: 1, action: 'Pushed code', resource: 'feature/auth branch', time: 'Today, 2:30 PM', icon: GitCommit },
  { id: 2, action: 'Viewed file', resource: 'src/components/Auth.tsx', time: 'Today, 2:15 PM', icon: Eye },
  { id: 3, action: 'Created PR', resource: 'PR #142: Auth implementation', time: 'Today, 1:45 PM', icon: FileCode },
  { id: 4, action: 'Logged in', resource: 'Developer Portal', time: 'Today, 9:00 AM', icon: LogIn },
  { id: 5, action: 'Pushed code', resource: 'develop branch', time: 'Yesterday, 5:30 PM', icon: GitCommit },
  { id: 6, action: 'Viewed file', resource: 'Database credentials', time: 'Yesterday, 3:00 PM', icon: Eye },
  { id: 7, action: 'Logged out', resource: 'Developer Portal', time: 'Yesterday, 6:00 PM', icon: LogOut },
];

export default function DeveloperActivityLogPage() {
  const [search, setSearch] = useState('');

  const filteredLogs = activityLogs.filter(log => 
    log.action.toLowerCase().includes(search.toLowerCase()) ||
    log.resource.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <RoleLayout role="developer">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Activity Log</h1>
            <p className="text-muted-foreground">Your recent actions (view only)</p>
          </div>
          <Badge variant="outline" className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
            <Activity className="h-3 w-3 mr-1" />
            {activityLogs.length} Entries
          </Badge>
        </div>

        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search activity..." className="pl-9" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              Recent Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Action</TableHead>
                  <TableHead>Resource</TableHead>
                  <TableHead>Time</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredLogs.map((log) => {
                  const Icon = log.icon;
                  return (
                    <TableRow key={log.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Icon className="h-4 w-4 text-cyan-400" />
                          <span className="font-medium">{log.action}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{log.resource}</TableCell>
                      <TableCell className="text-muted-foreground">{log.time}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <div className="p-4 rounded-lg bg-cyan-500/10 border border-cyan-500/30">
          <p className="text-sm text-cyan-400">
            <strong>Note:</strong> All your actions are logged for security and compliance purposes. This log shows only your own activities.
          </p>
        </div>
      </div>
    </RoleLayout>
  );
}
