import { RoleLayout } from '@/components/layout/RoleLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { FileText, Calendar, Clock } from 'lucide-react';

const workLogs = [
  { id: 1, date: 'Jan 6', task: 'Auth flow implementation', project: 'Main Platform', hours: 4.5, status: 'verified' },
  { id: 2, date: 'Jan 6', task: 'Code review for payment PR', project: 'E-commerce', hours: 1.5, status: 'verified' },
  { id: 3, date: 'Jan 5', task: 'Database query optimization', project: 'API Server', hours: 6, status: 'verified' },
  { id: 4, date: 'Jan 5', task: 'Bug fix: Login timeout', project: 'Main Platform', hours: 2, status: 'pending' },
  { id: 5, date: 'Jan 4', task: 'Unit tests for auth module', project: 'Main Platform', hours: 5, status: 'verified' },
  { id: 6, date: 'Jan 4', task: 'Sprint planning meeting', project: 'General', hours: 1, status: 'verified' },
];

const weeklySummary = {
  totalHours: 36,
  targetHours: 40,
  billableHours: 32,
  meetings: 4,
};

export default function DeveloperWorkLogPage() {
  return (
    <RoleLayout role="developer">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Work Log</h1>
            <p className="text-muted-foreground">Your logged work entries</p>
          </div>
          <Badge variant="outline" className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
            <Clock className="h-3 w-3 mr-1" />
            {weeklySummary.totalHours}h This Week
          </Badge>
        </div>

        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Total Hours</p>
              <p className="text-2xl font-bold">{weeklySummary.totalHours}h</p>
              <p className="text-xs text-muted-foreground">Target: {weeklySummary.targetHours}h</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Billable</p>
              <p className="text-2xl font-bold">{weeklySummary.billableHours}h</p>
              <p className="text-xs text-muted-foreground">{Math.round((weeklySummary.billableHours / weeklySummary.totalHours) * 100)}% of total</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Meetings</p>
              <p className="text-2xl font-bold">{weeklySummary.meetings}h</p>
              <p className="text-xs text-muted-foreground">Planning & standups</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Remaining</p>
              <p className="text-2xl font-bold">{weeklySummary.targetHours - weeklySummary.totalHours}h</p>
              <p className="text-xs text-muted-foreground">To reach target</p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Recent Entries
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Task</TableHead>
                  <TableHead>Project</TableHead>
                  <TableHead>Hours</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {workLogs.map((log) => (
                  <TableRow key={log.id}>
                    <TableCell className="font-medium">{log.date}</TableCell>
                    <TableCell>{log.task}</TableCell>
                    <TableCell>{log.project}</TableCell>
                    <TableCell>{log.hours}h</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={
                        log.status === 'verified' 
                          ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                          : 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                      }>
                        {log.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </RoleLayout>
  );
}
