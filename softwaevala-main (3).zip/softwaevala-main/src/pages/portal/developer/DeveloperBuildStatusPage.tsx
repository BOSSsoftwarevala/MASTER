import { RoleLayout } from '@/components/layout/RoleLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Hammer, CheckCircle, XCircle, Clock, Play } from 'lucide-react';

const builds = [
  { id: 1, name: 'main-platform', version: 'v2.4.2', branch: 'main', status: 'success', time: '4m 23s', date: 'Jan 6, 2:30 PM' },
  { id: 2, name: 'main-platform', version: 'v2.4.2-beta', branch: 'feature/auth', status: 'running', time: '2m 15s', date: 'Now' },
  { id: 3, name: 'api-server', version: 'v1.8.0', branch: 'develop', status: 'failed', time: '1m 45s', date: 'Jan 6, 1:00 PM' },
  { id: 4, name: 'mobile-app', version: 'v3.0.1', branch: 'main', status: 'success', time: '6m 12s', date: 'Jan 6, 10:00 AM' },
  { id: 5, name: 'admin-dashboard', version: 'v1.2.0', branch: 'main', status: 'success', time: '3m 45s', date: 'Jan 5, 5:00 PM' },
];

export default function DeveloperBuildStatusPage() {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success': return <CheckCircle className="h-5 w-5 text-emerald-400" />;
      case 'failed': return <XCircle className="h-5 w-5 text-red-400" />;
      case 'running': return <Play className="h-5 w-5 text-blue-400 animate-pulse" />;
      default: return <Clock className="h-5 w-5 text-muted-foreground" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'success': return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
      case 'failed': return 'bg-red-500/20 text-red-400 border-red-500/30';
      case 'running': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <RoleLayout role="developer">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Build Status</h1>
            <p className="text-muted-foreground">Recent build results</p>
          </div>
          <Badge variant="outline" className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
            <Hammer className="h-3 w-3 mr-1" />
            {builds.filter(b => b.status === 'success').length} Successful
          </Badge>
        </div>

        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Total Builds</p>
              <p className="text-2xl font-bold">{builds.length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Successful</p>
              <p className="text-2xl font-bold text-emerald-400">{builds.filter(b => b.status === 'success').length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Failed</p>
              <p className="text-2xl font-bold text-red-400">{builds.filter(b => b.status === 'failed').length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Running</p>
              <p className="text-2xl font-bold text-blue-400">{builds.filter(b => b.status === 'running').length}</p>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          {builds.map((build) => (
            <Card key={build.id}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    {getStatusIcon(build.status)}
                    <div>
                      <h3 className="font-medium">{build.name}</h3>
                      <p className="text-sm text-muted-foreground">{build.branch} • {build.version}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <Badge variant="outline" className={getStatusBadge(build.status)}>
                      {build.status}
                    </Badge>
                    <span className="text-sm text-muted-foreground">{build.time}</span>
                    <span className="text-sm text-muted-foreground w-32 text-right">{build.date}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </RoleLayout>
  );
}
