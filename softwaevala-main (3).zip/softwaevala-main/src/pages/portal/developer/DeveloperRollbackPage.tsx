import { RoleLayout } from '@/components/layout/RoleLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { RotateCcw, CheckCircle, AlertTriangle } from 'lucide-react';

const rollbackHistory = [
  { id: 1, version: 'v2.4.1', previousVersion: 'v2.4.0', reason: 'Critical bug in payment flow', initiatedBy: 'Manager', date: 'Jan 5, 2025', status: 'completed' },
  { id: 2, version: 'v2.3.8', previousVersion: 'v2.3.7', reason: 'Performance regression', initiatedBy: 'Manager', date: 'Dec 28, 2024', status: 'completed' },
  { id: 3, version: 'v2.2.5', previousVersion: 'v2.2.4', reason: 'Database connection issues', initiatedBy: 'System', date: 'Dec 15, 2024', status: 'completed' },
];

export default function DeveloperRollbackPage() {
  return (
    <RoleLayout role="developer">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Rollback History</h1>
            <p className="text-muted-foreground">Previous version rollbacks (view only)</p>
          </div>
          <Badge variant="outline" className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
            <RotateCcw className="h-3 w-3 mr-1" />
            {rollbackHistory.length} Rollbacks
          </Badge>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <RotateCcw className="h-5 w-5" />
              Rollback Log
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>To Version</TableHead>
                  <TableHead>From Version</TableHead>
                  <TableHead>Reason</TableHead>
                  <TableHead>Initiated By</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rollbackHistory.map((rollback) => (
                  <TableRow key={rollback.id}>
                    <TableCell className="font-mono font-medium">{rollback.version}</TableCell>
                    <TableCell className="font-mono text-muted-foreground">{rollback.previousVersion}</TableCell>
                    <TableCell>{rollback.reason}</TableCell>
                    <TableCell>{rollback.initiatedBy}</TableCell>
                    <TableCell>{rollback.date}</TableCell>
                    <TableCell>
                      <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        {rollback.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card className="bg-amber-500/10 border-amber-500/30">
          <CardContent className="p-4 flex items-center gap-3">
            <AlertTriangle className="h-5 w-5 text-amber-400" />
            <p className="text-sm text-amber-400">
              Rollback operations require Manager approval. Contact your team lead if an urgent rollback is needed.
            </p>
          </CardContent>
        </Card>
      </div>
    </RoleLayout>
  );
}
