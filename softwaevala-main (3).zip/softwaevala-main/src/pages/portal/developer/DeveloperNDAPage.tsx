import { RoleLayout } from '@/components/layout/RoleLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { FileCheck, CheckCircle, Clock, AlertTriangle } from 'lucide-react';

const ndaInfo = {
  status: 'signed',
  signedDate: 'Dec 1, 2024',
  expiryDate: 'Dec 1, 2025',
  version: '2.1',
  type: 'Standard Developer NDA',
};

const complianceItems = [
  { id: 1, title: 'Non-Disclosure Agreement', status: 'complete', date: 'Dec 1, 2024' },
  { id: 2, title: 'Code of Conduct', status: 'complete', date: 'Dec 1, 2024' },
  { id: 3, title: 'Security Training', status: 'complete', date: 'Dec 5, 2024' },
  { id: 4, title: 'Data Protection Certification', status: 'pending', dueDate: 'Jan 15, 2025' },
];

export default function DeveloperNDAPage() {
  return (
    <RoleLayout role="developer">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">NDA & Compliance</h1>
            <p className="text-muted-foreground">Your legal agreements status</p>
          </div>
          <Badge variant="outline" className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
            <CheckCircle className="h-3 w-3 mr-1" />
            Compliant
          </Badge>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileCheck className="h-5 w-5" />
              Non-Disclosure Agreement
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Status</span>
                  <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Signed
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Type</span>
                  <span className="font-medium">{ndaInfo.type}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Version</span>
                  <span className="font-medium">v{ndaInfo.version}</span>
                </div>
              </div>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Signed Date</span>
                  <span className="font-medium">{ndaInfo.signedDate}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Expiry Date</span>
                  <span className="font-medium">{ndaInfo.expiryDate}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Renewal</span>
                  <span className="font-medium">Auto-renew</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Compliance Checklist</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {complianceItems.map((item) => (
              <div key={item.id} className="flex items-center justify-between p-3 rounded-lg border">
                <div className="flex items-center gap-3">
                  {item.status === 'complete' 
                    ? <CheckCircle className="h-5 w-5 text-emerald-400" />
                    : <Clock className="h-5 w-5 text-amber-400" />
                  }
                  <span className="font-medium">{item.title}</span>
                </div>
                <div className="flex items-center gap-3">
                  {item.status === 'complete' ? (
                    <span className="text-sm text-muted-foreground">Completed {item.date}</span>
                  ) : (
                    <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">
                      Due: {item.dueDate}
                    </Badge>
                  )}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="bg-cyan-500/10 border-cyan-500/30">
          <CardContent className="p-4 flex items-center gap-3">
            <AlertTriangle className="h-5 w-5 text-cyan-400" />
            <p className="text-sm text-cyan-400">
              Your NDA covers all proprietary code, client data, and internal communications. Violations are logged and may result in account suspension.
            </p>
          </CardContent>
        </Card>
      </div>
    </RoleLayout>
  );
}
