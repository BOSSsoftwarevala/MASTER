import { RoleLayout } from '@/components/layout/RoleLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { FolderOpen, Search, Users, Calendar, GitBranch } from 'lucide-react';
import { useState } from 'react';

const projects = [
  { id: 1, name: 'Main Platform', description: 'Core SaaS platform development', status: 'active', progress: 68, team: 5, deadline: 'Feb 15', branch: 'main' },
  { id: 2, name: 'Mobile App', description: 'React Native mobile application', status: 'active', progress: 45, team: 3, deadline: 'Mar 1', branch: 'develop' },
  { id: 3, name: 'API Gateway', description: 'Microservices gateway layer', status: 'on_hold', progress: 20, team: 2, deadline: 'Apr 10', branch: 'feature/gateway' },
  { id: 4, name: 'Admin Dashboard', description: 'Internal admin tools', status: 'active', progress: 90, team: 2, deadline: 'Jan 20', branch: 'main' },
];

export default function DeveloperProjectsPage() {
  const [search, setSearch] = useState('');

  const filteredProjects = projects.filter(p => 
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    p.description.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <RoleLayout role="developer">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Assigned Projects</h1>
            <p className="text-muted-foreground">Projects you are contributing to</p>
          </div>
          <Badge variant="outline" className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
            <FolderOpen className="h-3 w-3 mr-1" />
            {projects.filter(p => p.status === 'active').length} Active
          </Badge>
        </div>

        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search projects..." className="pl-9" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          {filteredProjects.map((project) => (
            <Card key={project.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg">{project.name}</CardTitle>
                    <p className="text-sm text-muted-foreground">{project.description}</p>
                  </div>
                  <Badge variant="outline" className={
                    project.status === 'active' ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' :
                    'bg-amber-500/20 text-amber-400 border-amber-500/30'
                  }>
                    {project.status.replace('_', ' ')}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs text-muted-foreground">Progress</span>
                    <span className="text-xs font-medium">{project.progress}%</span>
                  </div>
                  <Progress value={project.progress} className="h-2" />
                </div>
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <Users className="h-4 w-4" />
                    <span>{project.team} members</span>
                  </div>
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <Calendar className="h-4 w-4" />
                    <span>{project.deadline}</span>
                  </div>
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <GitBranch className="h-4 w-4" />
                    <span>{project.branch}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </RoleLayout>
  );
}
