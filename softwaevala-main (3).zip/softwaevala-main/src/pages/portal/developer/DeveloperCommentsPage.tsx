import { RoleLayout } from '@/components/layout/RoleLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { MessageCircle, Send, Clock } from 'lucide-react';
import { useState } from 'react';

const taskComments = [
  { 
    id: 1, 
    task: 'Implement user authentication flow', 
    comments: [
      { id: 1, author: 'Manager', text: 'Please use OAuth2 for Google login', time: 'Jan 5, 2:30 PM' },
      { id: 2, author: 'You', text: 'Got it. Already integrated with Google SDK.', time: 'Jan 5, 3:15 PM' },
    ]
  },
  { 
    id: 2, 
    task: 'Fix payment gateway timeout', 
    comments: [
      { id: 1, author: 'QA', text: 'Timeout happening after 10 seconds on slow networks', time: 'Jan 4, 11:00 AM' },
    ]
  },
];

export default function DeveloperCommentsPage() {
  const [newComment, setNewComment] = useState('');

  return (
    <RoleLayout role="developer">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Task Comments</h1>
            <p className="text-muted-foreground">Communication threads on your tasks</p>
          </div>
          <Badge variant="outline" className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
            <MessageCircle className="h-3 w-3 mr-1" />
            {taskComments.reduce((acc, t) => acc + t.comments.length, 0)} Comments
          </Badge>
        </div>

        <div className="space-y-6">
          {taskComments.map((task) => (
            <Card key={task.id}>
              <CardHeader>
                <CardTitle className="text-lg">{task.task}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {task.comments.map((comment) => (
                  <div key={comment.id} className="flex gap-3 pb-3 border-b last:border-0">
                    <div className="w-8 h-8 rounded-full bg-cyan-500/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-xs font-medium text-cyan-400">{comment.author[0]}</span>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-sm">{comment.author}</span>
                        <span className="text-xs text-muted-foreground flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {comment.time}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground">{comment.text}</p>
                    </div>
                  </div>
                ))}
                <div className="flex gap-2 pt-2">
                  <Textarea placeholder="Add a comment..." value={newComment} onChange={(e) => setNewComment(e.target.value)} className="min-h-[60px]" />
                  <Button size="icon" className="self-end">
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </RoleLayout>
  );
}
