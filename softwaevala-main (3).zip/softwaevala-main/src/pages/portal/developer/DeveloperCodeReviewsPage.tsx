import { RoleLayout } from '@/components/layout/RoleLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { GitPullRequest, MessageSquare, Clock, CheckCircle, XCircle } from 'lucide-react';

const reviews = [
  { id: 1, title: 'feat: Add user authentication', author: 'Alex Chen', branch: 'feature/auth', status: 'pending', comments: 3, files: 12, time: '2h ago' },
  { id: 2, title: 'fix: Payment gateway timeout', author: 'Sarah Kim', branch: 'fix/payment', status: 'approved', comments: 5, files: 4, time: '4h ago' },
  { id: 3, title: 'refactor: Database queries', author: 'Mike Johnson', branch: 'refactor/db', status: 'changes_requested', comments: 8, files: 7, time: '1d ago' },
  { id: 4, title: 'feat: Export functionality', author: 'Emily Davis', branch: 'feature/export', status: 'pending', comments: 1, files: 5, time: '3h ago' },
];

export default function DeveloperCodeReviewsPage() {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30"><CheckCircle className="h-3 w-3 mr-1" />Approved</Badge>;
      case 'changes_requested':
        return <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30"><XCircle className="h-3 w-3 mr-1" />Changes</Badge>;
      default:
        return <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30"><Clock className="h-3 w-3 mr-1" />Pending</Badge>;
    }
  };

  return (
    <RoleLayout role="developer">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Code Review Requests</h1>
            <p className="text-muted-foreground">Pull requests awaiting your review</p>
          </div>
          <Badge variant="outline" className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
            <GitPullRequest className="h-3 w-3 mr-1" />
            {reviews.filter(r => r.status === 'pending').length} Pending
          </Badge>
        </div>

        <div className="space-y-4">
          {reviews.map((review) => (
            <Card key={review.id}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3">
                    <GitPullRequest className="h-5 w-5 text-cyan-400 mt-1" />
                    <div>
                      <h3 className="font-medium">{review.title}</h3>
                      <p className="text-sm text-muted-foreground">
                        {review.author} • {review.branch} • {review.files} files
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {getStatusBadge(review.status)}
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <MessageSquare className="h-4 w-4" />
                      <span className="text-sm">{review.comments}</span>
                    </div>
                    <span className="text-xs text-muted-foreground">{review.time}</span>
                    <Button size="sm" variant="outline">Review</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </RoleLayout>
  );
}
