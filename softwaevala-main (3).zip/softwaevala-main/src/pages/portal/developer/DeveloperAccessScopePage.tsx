import { RoleLayout } from '@/components/layout/RoleLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Shield, CheckCircle, XCircle, AlertTriangle, Lock } from 'lucide-react';

const accessScopes = [
  { id: 1, resource: 'Main Platform Repository', access: 'read_write', granted: 'Dec 1, 2024', expires: 'Never' },
  { id: 2, resource: 'API Server Repository', access: 'read_only', granted: 'Dec 5, 2024', expires: 'Never' },
  { id: 3, resource: 'Production Database', access: 'none', granted: '-', expires: '-' },
  { id: 4, resource: 'Staging Environment', access: 'read_write', granted: 'Dec 1, 2024', expires: 'Never' },
  { id: 5, resource: 'Client Data', access: 'none', granted: '-', expires: '-' },
  { id: 6, resource: 'Financial Reports', access: 'none', granted: '-', expires: '-' },
];

const getAccessBadge = (access: string) => {
  switch (access) {
    case 'read_write':
      return <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30"><CheckCircle className="h-3 w-3 mr-1" />Read/Write</Badge>;
    case 'read_only':
      return <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30"><Lock className="h-3 w-3 mr-1" />Read Only</Badge>;
    default:
      return <Badge className="bg-red-500/20 text-red-400 border-red-500/30"><XCircle className="h-3 w-3 mr-1" />No Access</Badge>;
  }
};

export default function DeveloperAccessScopePage() {
  const grantedScopes = accessScopes.filter(s => s.access !== 'none').length;
  
  return (
    <RoleLayout role="developer">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Access Scope</h1>
            <p className="text-muted-foreground">Your current resource permissions</p>
          </div>
          <Badge variant="outline" className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
            <Shield className="h-3 w-3 mr-1" />
            {grantedScopes} Active Scopes
          </Badge>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Resource Permissions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Resource</TableHead>
                  <TableHead>Access Level</TableHead>
                  <TableHead>Granted</TableHead>
                  <TableHead>Expires</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {accessScopes.map((scope) => (
                  <TableRow key={scope.id}>
                    <TableCell className="font-medium">{scope.resource}</TableCell>
                    <TableCell>{getAccessBadge(scope.access)}</TableCell>
                    <TableCell className="text-muted-foreground">{scope.granted}</TableCell>
                    <TableCell className="text-muted-foreground">{scope.expires}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card className="bg-amber-500/10 border-amber-500/30">
          <CardContent className="p-4 flex items-center gap-3">
            <AlertTriangle className="h-5 w-5 text-amber-400" />
            <p className="text-sm text-amber-400">
              This is a read-only view of your permissions. To request additional access, contact your Manager through the internal chat.
            </p>
          </CardContent>
        </Card>
      </div>
    </RoleLayout>
  );
}
