import { RoleLayout } from '@/components/layout/RoleLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Kanban, Clock, CheckCircle, Circle } from 'lucide-react';

const sprintTasks = {
  todo: [
    { id: 1, title: 'Setup CI/CD pipeline', priority: 'high', estimate: '4h' },
    { id: 2, title: 'Write API documentation', priority: 'medium', estimate: '3h' },
  ],
  inProgress: [
    { id: 3, title: 'Implement auth flow', priority: 'critical', estimate: '8h', logged: '5h' },
    { id: 4, title: 'Database optimization', priority: 'high', estimate: '6h', logged: '2h' },
  ],
  done: [
    { id: 5, title: 'User profile page', priority: 'medium', estimate: '4h' },
    { id: 6, title: 'Error handling', priority: 'high', estimate: '3h' },
  ],
};

const getPriorityColor = (priority: string) => {
  switch (priority) {
    case 'critical': return 'bg-red-500/20 text-red-400 border-red-500/30';
    case 'high': return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
    case 'medium': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
    default: return 'bg-slate-500/20 text-slate-400 border-slate-500/30';
  }
};

const TaskCard = ({ task }: { task: { id: number; title: string; priority: string; estimate: string; logged?: string } }) => (
  <Card className="mb-3">
    <CardContent className="p-3">
      <p className="font-medium text-sm mb-2">{task.title}</p>
      <div className="flex items-center justify-between">
        <Badge variant="outline" className={getPriorityColor(task.priority)}>
          {task.priority}
        </Badge>
        <span className="text-xs text-muted-foreground">
          {task.logged ? `${task.logged} / ${task.estimate}` : task.estimate}
        </span>
      </div>
    </CardContent>
  </Card>
);

export default function DeveloperSprintBoardPage() {
  return (
    <RoleLayout role="developer">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Sprint Board</h1>
            <p className="text-muted-foreground">Sprint 24 • Jan 1 - Jan 14</p>
          </div>
          <Badge variant="outline" className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
            <Kanban className="h-3 w-3 mr-1" />
            6 Tasks
          </Badge>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Circle className="h-4 w-4 text-slate-400" />
                To Do
                <Badge variant="secondary" className="ml-auto">{sprintTasks.todo.length}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {sprintTasks.todo.map(task => <TaskCard key={task.id} task={task} />)}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Clock className="h-4 w-4 text-blue-400" />
                In Progress
                <Badge variant="secondary" className="ml-auto">{sprintTasks.inProgress.length}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {sprintTasks.inProgress.map(task => <TaskCard key={task.id} task={task} />)}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-emerald-400" />
                Done
                <Badge variant="secondary" className="ml-auto">{sprintTasks.done.length}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {sprintTasks.done.map(task => <TaskCard key={task.id} task={task} />)}
            </CardContent>
          </Card>
        </div>
      </div>
    </RoleLayout>
  );
}
