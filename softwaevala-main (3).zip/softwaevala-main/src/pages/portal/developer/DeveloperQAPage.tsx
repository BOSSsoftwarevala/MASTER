import { RoleLayout } from '@/components/layout/RoleLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TestTube, CheckCircle, XCircle, Clock, MessageSquare } from 'lucide-react';

const testResults = [
  { id: 1, suite: 'Auth Module', passed: 24, failed: 0, time: '1.2s', status: 'passed' },
  { id: 2, suite: 'Payment Integration', passed: 18, failed: 2, time: '3.4s', status: 'failed' },
  { id: 3, suite: 'User Management', passed: 32, failed: 0, time: '2.1s', status: 'passed' },
  { id: 4, suite: 'API Endpoints', passed: 45, failed: 1, time: '4.8s', status: 'failed' },
];

const qaFeedback = [
  { id: 1, task: 'Auth flow implementation', tester: 'QA Team', status: 'approved', feedback: 'All test cases passed. Ready for release.', date: 'Jan 6' },
  { id: 2, task: 'Payment gateway fix', tester: 'QA Team', status: 'needs_work', feedback: 'Edge case fails: timeout on slow connections.', date: 'Jan 5' },
  { id: 3, task: 'Export functionality', tester: 'QA Team', status: 'pending', feedback: 'Scheduled for testing tomorrow.', date: 'Jan 5' },
];

export default function DeveloperQAPage() {
  return (
    <RoleLayout role="developer">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Quality Assurance</h1>
            <p className="text-muted-foreground">Test results and QA feedback</p>
          </div>
          <Badge variant="outline" className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
            <TestTube className="h-3 w-3 mr-1" />
            119 Tests
          </Badge>
        </div>

        <Tabs defaultValue="results">
          <TabsList>
            <TabsTrigger value="results">Test Results</TabsTrigger>
            <TabsTrigger value="feedback">QA Feedback</TabsTrigger>
          </TabsList>

          <TabsContent value="results" className="space-y-4">
            {testResults.map((result) => (
              <Card key={result.id}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {result.status === 'passed' 
                        ? <CheckCircle className="h-5 w-5 text-emerald-400" />
                        : <XCircle className="h-5 w-5 text-red-400" />
                      }
                      <div>
                        <h3 className="font-medium">{result.suite}</h3>
                        <p className="text-sm text-muted-foreground">{result.time}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                        {result.passed} passed
                      </Badge>
                      {result.failed > 0 && (
                        <Badge className="bg-red-500/20 text-red-400 border-red-500/30">
                          {result.failed} failed
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="feedback" className="space-y-4">
            {qaFeedback.map((item) => (
              <Card key={item.id}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="font-medium">{item.task}</h3>
                      <p className="text-sm text-muted-foreground">{item.tester} • {item.date}</p>
                    </div>
                    <Badge variant="outline" className={
                      item.status === 'approved' ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' :
                      item.status === 'needs_work' ? 'bg-amber-500/20 text-amber-400 border-amber-500/30' :
                      'bg-blue-500/20 text-blue-400 border-blue-500/30'
                    }>
                      {item.status.replace('_', ' ')}
                    </Badge>
                  </div>
                  <div className="flex items-start gap-2 mt-3 p-3 rounded bg-muted/50">
                    <MessageSquare className="h-4 w-4 text-muted-foreground mt-0.5" />
                    <p className="text-sm">{item.feedback}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>
        </Tabs>
      </div>
    </RoleLayout>
  );
}
