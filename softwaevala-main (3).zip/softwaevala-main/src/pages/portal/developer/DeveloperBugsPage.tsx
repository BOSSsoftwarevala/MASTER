import { RoleLayout } from '@/components/layout/RoleLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { 
  Bug, 
  AlertTriangle,
  Clock,
  CheckCircle,
  Play,
  Brain,
  ArrowRight
} from 'lucide-react';

const assignedBugs = [
  { 
    id: 'BUG-1234',
    title: 'Payment fails for international cards',
    project: 'E-commerce Module',
    severity: 'critical',
    status: 'in_progress',
    assignedAt: '2 days ago',
    deadline: 'Today',
    aiInsight: 'Likely caused by currency conversion issue in Stripe integration'
  },
  { 
    id: 'BUG-1235',
    title: 'Login timeout too short',
    project: 'Main Platform',
    severity: 'high',
    status: 'assigned',
    assignedAt: '1 day ago',
    deadline: 'Tomorrow',
    aiInsight: 'Session timeout set to 5 minutes, recommend 30 minutes'
  },
  { 
    id: 'BUG-1236',
    title: 'Dashboard charts not loading on mobile',
    project: 'Analytics Dashboard',
    severity: 'medium',
    status: 'assigned',
    assignedAt: '3 hours ago',
    deadline: 'Jan 8',
    aiInsight: 'Responsive breakpoint issue detected in chart component'
  },
  { 
    id: 'BUG-1237',
    title: 'Email notifications delayed',
    project: 'Notification Service',
    severity: 'low',
    status: 'resolved',
    assignedAt: '4 days ago',
    resolvedAt: 'Yesterday',
    aiInsight: null
  },
];

export default function DeveloperBugsPage() {
  return (
    <RoleLayout role="developer">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Bug Assignment</h1>
            <p className="text-muted-foreground">View and fix bugs assigned to you</p>
          </div>
          <Badge variant="outline" className="bg-red-500/20 text-red-400 border-red-500/30">
            <Bug className="h-3 w-3 mr-1" />
            3 Active Bugs
          </Badge>
        </div>

        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-red-500/20 flex items-center justify-center">
                  <AlertTriangle className="h-5 w-5 text-red-500" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Critical</p>
                  <p className="text-2xl font-bold">1</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-amber-500/20 flex items-center justify-center">
                  <Bug className="h-5 w-5 text-amber-500" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">High</p>
                  <p className="text-2xl font-bold">1</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                  <Play className="h-5 w-5 text-blue-500" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">In Progress</p>
                  <p className="text-2xl font-bold">1</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-emerald-500/20 flex items-center justify-center">
                  <CheckCircle className="h-5 w-5 text-emerald-500" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Resolved</p>
                  <p className="text-2xl font-bold">1</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Bug List */}
        <Card>
          <CardHeader>
            <CardTitle>Assigned Bugs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {assignedBugs.map((bug) => (
                <div key={bug.id} className={`p-4 rounded-lg border ${
                  bug.status === 'resolved' ? 'bg-muted/30' :
                  bug.severity === 'critical' ? 'bg-red-500/10 border-red-500/30' :
                  bug.severity === 'high' ? 'bg-amber-500/10 border-amber-500/30' :
                  'bg-muted/50'
                }`}>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4">
                      <div className={`h-10 w-10 rounded-lg flex items-center justify-center ${
                        bug.status === 'resolved' ? 'bg-emerald-500/20' :
                        bug.severity === 'critical' ? 'bg-red-500/20' :
                        bug.severity === 'high' ? 'bg-amber-500/20' :
                        'bg-blue-500/20'
                      }`}>
                        {bug.status === 'resolved' ? (
                          <CheckCircle className="h-5 w-5 text-emerald-500" />
                        ) : (
                          <Bug className={`h-5 w-5 ${
                            bug.severity === 'critical' ? 'text-red-500' :
                            bug.severity === 'high' ? 'text-amber-500' :
                            'text-blue-500'
                          }`} />
                        )}
                      </div>
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-mono text-sm text-muted-foreground">{bug.id}</span>
                          <Badge variant="outline" className={
                            bug.severity === 'critical' ? 'bg-red-500/20 text-red-400 border-red-500/30' :
                            bug.severity === 'high' ? 'bg-amber-500/20 text-amber-400 border-amber-500/30' :
                            bug.severity === 'medium' ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' :
                            'bg-slate-500/20 text-slate-400 border-slate-500/30'
                          }>
                            {bug.severity}
                          </Badge>
                        </div>
                        <p className="font-medium">{bug.title}</p>
                        <p className="text-sm text-muted-foreground">{bug.project}</p>
                        
                        {bug.aiInsight && (
                          <div className="mt-3 p-2 rounded bg-cyan-500/10 border border-cyan-500/30">
                            <div className="flex items-start gap-2">
                              <Brain className="h-4 w-4 text-cyan-500 mt-0.5" />
                              <p className="text-xs text-cyan-400">{bug.aiInsight}</p>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge variant="outline" className={
                        bug.status === 'resolved' ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' :
                        bug.status === 'in_progress' ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' :
                        'bg-slate-500/20 text-slate-400 border-slate-500/30'
                      }>
                        {bug.status.replace('_', ' ')}
                      </Badge>
                      {bug.deadline && bug.status !== 'resolved' && (
                        <p className="text-xs text-muted-foreground mt-2 flex items-center gap-1 justify-end">
                          <Clock className="h-3 w-3" />
                          Due: {bug.deadline}
                        </p>
                      )}
                      {bug.status !== 'resolved' && (
                        <Button size="sm" className="mt-2">
                          {bug.status === 'in_progress' ? 'View Details' : 'Start Fix'}
                          <ArrowRight className="h-3 w-3 ml-1" />
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Info */}
        <div className="p-4 rounded-lg bg-cyan-500/10 border border-cyan-500/30">
          <p className="text-sm text-cyan-400">
            <strong>AI Insight:</strong> Based on your fix history, you resolve critical bugs 40% faster 
            than average. Keep up the great work!
          </p>
        </div>
      </div>
    </RoleLayout>
  );
}
