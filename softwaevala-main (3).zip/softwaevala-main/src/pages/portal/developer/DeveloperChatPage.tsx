import { RoleLayout } from '@/components/layout/RoleLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { MessageSquare, Send, User } from 'lucide-react';
import { useState } from 'react';

const chatHistory = [
  { id: 1, sender: 'Manager', message: 'How is the auth implementation going?', time: '10:30 AM', isMe: false },
  { id: 2, sender: 'You', message: 'Almost done. Just need to finish the OAuth integration.', time: '10:32 AM', isMe: true },
  { id: 3, sender: 'Manager', message: 'Great! Let me know if you need any help with the credentials.', time: '10:33 AM', isMe: false },
  { id: 4, sender: 'You', message: 'Will do. Should be ready for review by EOD.', time: '10:35 AM', isMe: true },
];

const contacts = [
  { id: 1, name: 'Dev Manager', role: 'Manager', status: 'online', unread: 0 },
  { id: 2, name: 'Tech Lead', role: 'Lead', status: 'online', unread: 2 },
  { id: 3, name: 'QA Team', role: 'Team', status: 'online', unread: 0 },
];

export default function DeveloperChatPage() {
  const [message, setMessage] = useState('');

  return (
    <RoleLayout role="developer">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Internal Chat</h1>
            <p className="text-muted-foreground">Developer to Manager communication</p>
          </div>
          <Badge variant="outline" className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
            <MessageSquare className="h-3 w-3 mr-1" />
            {contacts.filter(c => c.status === 'online').length} Online
          </Badge>
        </div>

        <div className="grid gap-4 md:grid-cols-4 h-[600px]">
          <Card className="md:col-span-1">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Contacts</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {contacts.map((contact) => (
                <div key={contact.id} className="flex items-center justify-between px-4 py-3 hover:bg-muted/50 cursor-pointer border-b last:border-0">
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <div className="w-10 h-10 rounded-full bg-cyan-500/20 flex items-center justify-center">
                        <User className="h-5 w-5 text-cyan-400" />
                      </div>
                      <div className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-background ${contact.status === 'online' ? 'bg-emerald-400' : 'bg-muted'}`} />
                    </div>
                    <div>
                      <p className="font-medium text-sm">{contact.name}</p>
                      <p className="text-xs text-muted-foreground">{contact.role}</p>
                    </div>
                  </div>
                  {contact.unread > 0 && (
                    <Badge className="bg-cyan-500">{contact.unread}</Badge>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="md:col-span-3 flex flex-col">
            <CardHeader className="pb-3 border-b">
              <CardTitle className="text-lg flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-cyan-500/20 flex items-center justify-center">
                  <User className="h-4 w-4 text-cyan-400" />
                </div>
                Dev Manager
              </CardTitle>
            </CardHeader>
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-4">
                {chatHistory.map((msg) => (
                  <div key={msg.id} className={`flex ${msg.isMe ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[70%] rounded-lg px-4 py-2 ${msg.isMe ? 'bg-cyan-500 text-white' : 'bg-muted'}`}>
                      <p className="text-sm">{msg.message}</p>
                      <p className={`text-xs mt-1 ${msg.isMe ? 'text-cyan-100' : 'text-muted-foreground'}`}>{msg.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
            <div className="p-4 border-t">
              <div className="flex items-center gap-2">
                <Input placeholder="Type a message..." value={message} onChange={(e) => setMessage(e.target.value)} className="flex-1" />
                <Button size="icon">
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </RoleLayout>
  );
}
