import { useState } from 'react';
import { RoleLayout } from '@/components/layout/RoleLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { 
  User, Mail, Phone, MapPin, Shield, Key, Smartphone, 
  Lock, LogOut, AlertTriangle, CheckCircle, Monitor,
  Code, Github, Clock, Calendar, Award, MessageSquare, LifeBuoy, FileText
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function DeveloperProfilePage() {
  const { toast } = useToast();
  const [is2FAEnabled, setIs2FAEnabled] = useState(true);
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [showForgotPassword, setShowForgotPassword] = useState(false);

  const handleChangePassword = () => {
    toast({
      title: "Password Updated",
      description: "Your password has been changed successfully.",
    });
    setShowChangePassword(false);
  };

  const handleForgotPassword = () => {
    toast({
      title: "Reset Link Sent",
      description: "Check your email for password reset instructions.",
    });
    setShowForgotPassword(false);
  };

  const handleLogoutDevice = (deviceId: string) => {
    toast({
      title: "Session Terminated",
      description: "The device has been logged out.",
    });
  };

  const handleLogoutAll = () => {
    toast({
      title: "All Sessions Terminated",
      description: "All other devices have been logged out.",
    });
  };

  return (
    <RoleLayout role="developer">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Profile & Settings</h1>
          <p className="text-muted-foreground">Manage your developer account and security</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Personal Information */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Personal Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-4">
                  <Avatar className="h-20 w-20">
                    <AvatarImage src="/placeholder.svg" />
                    <AvatarFallback className="bg-cyan-500/20 text-cyan-400 text-xl">JD</AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="text-xl font-semibold">John Developer</h3>
                    <p className="text-muted-foreground">Senior Full-Stack Developer</p>
                    <p className="text-sm text-muted-foreground">Member since January 2024</p>
                  </div>
                </div>

                <Separator />

                <div className="grid gap-4">
                  <div className="flex items-center gap-3">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <span>john.dev@company.com</span>
                    <Badge variant="outline" className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                      Verified
                    </Badge>
                  </div>
                  <div className="flex items-center gap-3">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span>+1 (555) ***-**89</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span>San Francisco, CA</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Github className="h-4 w-4 text-muted-foreground" />
                    <span>github.com/johndev</span>
                  </div>
                </div>

                <Button variant="outline" className="mt-4">Edit Profile</Button>
              </CardContent>
            </Card>

            {/* Developer Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code className="h-5 w-5" />
                  Developer Stats
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center p-4 rounded-lg bg-muted/50">
                    <p className="text-2xl font-bold text-cyan-400">147</p>
                    <p className="text-sm text-muted-foreground">Tasks Completed</p>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-muted/50">
                    <p className="text-2xl font-bold text-emerald-400">89</p>
                    <p className="text-sm text-muted-foreground">PRs Merged</p>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-muted/50">
                    <p className="text-2xl font-bold text-violet-400">23</p>
                    <p className="text-sm text-muted-foreground">Bugs Fixed</p>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-muted/50">
                    <p className="text-2xl font-bold text-amber-400">4.8</p>
                    <p className="text-sm text-muted-foreground">Code Rating</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Account Security */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  Account Security
                </CardTitle>
                <CardDescription>Manage your password and authentication settings</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Change Password */}
                <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-cyan-500/20">
                      <Key className="h-5 w-5 text-cyan-400" />
                    </div>
                    <div>
                      <p className="font-medium">Change Password</p>
                      <p className="text-sm text-muted-foreground">Update your account password</p>
                    </div>
                  </div>
                  <Dialog open={showChangePassword} onOpenChange={setShowChangePassword}>
                    <DialogTrigger asChild>
                      <Button variant="outline">Change</Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Change Password</DialogTitle>
                        <DialogDescription>Enter your current password and choose a new one</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 py-4">
                        <div className="space-y-2">
                          <Label>Current Password</Label>
                          <Input type="password" placeholder="Enter current password" />
                        </div>
                        <div className="space-y-2">
                          <Label>New Password</Label>
                          <Input type="password" placeholder="Enter new password" />
                        </div>
                        <div className="space-y-2">
                          <Label>Confirm New Password</Label>
                          <Input type="password" placeholder="Confirm new password" />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button variant="outline" onClick={() => setShowChangePassword(false)}>Cancel</Button>
                        <Button onClick={handleChangePassword}>Update Password</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>

                {/* Forgot Password */}
                <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-amber-500/20">
                      <Lock className="h-5 w-5 text-amber-400" />
                    </div>
                    <div>
                      <p className="font-medium">Forgot Password</p>
                      <p className="text-sm text-muted-foreground">Reset your password via email</p>
                    </div>
                  </div>
                  <Dialog open={showForgotPassword} onOpenChange={setShowForgotPassword}>
                    <DialogTrigger asChild>
                      <Button variant="outline">Reset</Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Reset Password</DialogTitle>
                        <DialogDescription>We'll send a reset link to your registered email</DialogDescription>
                      </DialogHeader>
                      <div className="py-4">
                        <div className="p-4 rounded-lg bg-amber-500/10 border border-amber-500/30">
                          <div className="flex items-start gap-3">
                            <AlertTriangle className="h-5 w-5 text-amber-500 mt-0.5" />
                            <p className="text-sm text-amber-400">
                              This will invalidate all active sessions. You'll need to log in again on all devices.
                            </p>
                          </div>
                        </div>
                      </div>
                      <DialogFooter>
                        <Button variant="outline" onClick={() => setShowForgotPassword(false)}>Cancel</Button>
                        <Button onClick={handleForgotPassword}>Send Reset Link</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>

                {/* Two-Factor Authentication */}
                <div className="p-4 rounded-lg bg-muted/50 space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-emerald-500/20">
                        <Smartphone className="h-5 w-5 text-emerald-400" />
                      </div>
                      <div>
                        <p className="font-medium">Two-Factor Authentication</p>
                        <p className="text-sm text-muted-foreground">
                          {is2FAEnabled ? 'Enabled via Email OTP' : 'Add extra security to your account'}
                        </p>
                      </div>
                    </div>
                    <Switch checked={is2FAEnabled} onCheckedChange={setIs2FAEnabled} />
                  </div>
                  {is2FAEnabled && (
                    <div className="grid grid-cols-3 gap-4 pt-2">
                      <div className="text-center p-3 rounded-lg border">
                        <p className="text-sm font-medium">Email OTP</p>
                        <Badge className="mt-1 bg-emerald-500/20 text-emerald-400 border-emerald-500/30">Active</Badge>
                      </div>
                      <div className="text-center p-3 rounded-lg border">
                        <p className="text-sm font-medium">SMS OTP</p>
                        <Badge variant="outline" className="mt-1">Not Set</Badge>
                      </div>
                      <div className="text-center p-3 rounded-lg border">
                        <p className="text-sm font-medium">Auth App</p>
                        <Badge variant="outline" className="mt-1">Not Set</Badge>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Active Sessions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Monitor className="h-5 w-5" />
                  Active Sessions
                </CardTitle>
                <CardDescription>Devices where you're currently logged in</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {[
                  { id: '1', device: 'MacBook Pro', location: 'San Francisco, CA', lastActive: 'Now', current: true },
                  { id: '2', device: 'iPhone 15 Pro', location: 'San Francisco, CA', lastActive: '2 hours ago', current: false },
                  { id: '3', device: 'Windows PC', location: 'New York, NY', lastActive: 'Yesterday', current: false },
                ].map((session) => (
                  <div key={session.id} className="flex items-center justify-between p-4 rounded-lg border">
                    <div className="flex items-center gap-3">
                      <Monitor className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="font-medium">{session.device}</p>
                          {session.current && (
                            <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">Current</Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {session.location} • {session.lastActive}
                        </p>
                      </div>
                    </div>
                    {!session.current && (
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="text-red-400 hover:text-red-300"
                        onClick={() => handleLogoutDevice(session.id)}
                      >
                        <LogOut className="h-4 w-4 mr-1" />
                        Logout
                      </Button>
                    )}
                  </div>
                ))}
                <Button variant="outline" className="w-full text-red-400 hover:text-red-300" onClick={handleLogoutAll}>
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout All Other Devices
                </Button>
              </CardContent>
            </Card>

            {/* Support Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LifeBuoy className="h-5 w-5" />
                  Help & Support
                </CardTitle>
              </CardHeader>
              <CardContent className="grid gap-4 md:grid-cols-2">
                <Button variant="outline" className="justify-start h-auto py-4">
                  <MessageSquare className="h-5 w-5 mr-3 text-cyan-400" />
                  <div className="text-left">
                    <p className="font-medium">Chat with Support</p>
                    <p className="text-sm text-muted-foreground">Get help with technical issues</p>
                  </div>
                </Button>
                <Button variant="outline" className="justify-start h-auto py-4">
                  <FileText className="h-5 w-5 mr-3 text-violet-400" />
                  <div className="text-left">
                    <p className="font-medium">Report a Bug</p>
                    <p className="text-sm text-muted-foreground">Submit internal bug reports</p>
                  </div>
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Access Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Access Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Role</span>
                  <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">Developer</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Access Level</span>
                  <span className="font-medium">Full Repo</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Access Expires</span>
                  <span className="font-medium">Mar 15, 2026</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">NDA Status</span>
                  <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Signed
                  </Badge>
                </div>
              </CardContent>
            </Card>

            {/* Skills & Certifications */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Award className="h-5 w-5" />
                  Skills
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {['React', 'TypeScript', 'Node.js', 'PostgreSQL', 'Docker', 'AWS'].map((skill) => (
                    <Badge key={skill} variant="outline">{skill}</Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Work Schedule */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  Work Schedule
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Timezone</span>
                  <span className="font-medium">PST (UTC-8)</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Work Hours</span>
                  <span className="font-medium">9 AM - 6 PM</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">This Week</span>
                  <span className="font-medium">36h logged</span>
                </div>
              </CardContent>
            </Card>

            {/* Security Notice */}
            <div className="p-4 rounded-lg bg-cyan-500/10 border border-cyan-500/30">
              <div className="flex items-start gap-3">
                <Shield className="h-5 w-5 text-cyan-400 mt-0.5" />
                <div>
                  <p className="font-medium text-cyan-400">Security Notice</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    All password changes and session activity are logged for security audit purposes.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </RoleLayout>
  );
}
